function navActive(){
  const path = location.pathname.replace(/\/index\.html$/,'/');
  document.querySelectorAll('a[data-nav]').forEach(a=>{
    if(a.getAttribute('href')===path || a.getAttribute('href')===location.pathname){
      a.style.fontWeight='700';
    }
  });
}
document.addEventListener('DOMContentLoaded', navActive);

// simple mailto for admissions form
function handleAdmissionSubmit(e){
  e.preventDefault();
  const f = e.target;
  const data = new FormData(f);
  const name = data.get('name')||'';
  const email = data.get('email')||'';
  const phone = data.get('phone')||'';
  const level = data.get('level')||'';
  const country = data.get('country')||'';
  const message = data.get('message')||'';
  const subject = encodeURIComponent(`Application — ${level} — ${name}`);
  const body = encodeURIComponent(
`Name: ${name}
Email: ${email}
Phone: ${phone}
Country: ${country}
Program Level: ${level}

Message:
${message}

(Please find my transcripts and passport photo attached.)`
  );
  window.location.href = `mailto:admissions@hibiafrica.org?subject=${subject}&body=${body}`;
  alert('Thank you! Your email app will open with your application. Attach your documents and send.');
}
